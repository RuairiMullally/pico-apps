# LAB08 NOTES

See [LAB #08](https://tcd.blackboard.com/webapps/assignment/uploadAssignment?content_id=_2130569_1&course_id=_71874_1&group_id=&mode=cpview) on the module Blackboard site for details of this lab.
